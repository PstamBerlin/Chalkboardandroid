pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // GeckoView lives in Mozilla's own Maven repo.
        maven("https://maven.mozilla.org/maven2/")
    }
}

rootProject.name = "Chalkboard"
include(":app")

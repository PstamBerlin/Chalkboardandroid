package eu.chalkboard.browser

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import eu.chalkboard.browser.ui.BrowserScreen

class MainActivity : ComponentActivity() {

    private lateinit var browser: Browser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        browser = Browser(this)

        // A link handed over from another app, or the launcher with nothing.
        val opening = intent?.dataString
        browser.newTab(opening ?: browser.prefs.homeUrl)

        setContent {
            val b = remember { browser }
            BrowserScreen(b)
        }

        onBackPressedDispatcher.addCallback(this) {
            val tab = browser.active
            when {
                browser.trayOpen -> browser.trayOpen = false
                browser.findOpen -> browser.findOpen = false
                tab?.canBack == true -> tab.session.goBack()
                browser.tabs.size > 1 -> browser.closeTab()
                else -> finish()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.dataString?.let { browser.newTab(it) }
    }

    override fun onDestroy() {
        if (browser.prefs.clearOnExit) Engine.clearBrowsingData()
        super.onDestroy()
    }
}

/** Small helper so the back handler above reads cleanly. */
private fun androidx.activity.OnBackPressedDispatcher.addCallback(
    owner: androidx.lifecycle.LifecycleOwner,
    handler: () -> Unit,
) {
    addCallback(owner, object : androidx.activity.OnBackPressedCallback(true) {
        override fun handleOnBackPressed() = handler()
    })
}

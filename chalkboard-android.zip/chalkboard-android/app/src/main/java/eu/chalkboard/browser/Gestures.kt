package eu.chalkboard.browser

import android.content.Context
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.dp
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.math.abs

/**
 * Gestures are the part of a phone browser that either makes it feel great
 * or makes it feel like a website in a box. Everything here is remappable,
 * because what feels natural is different for everyone.
 */

enum class Gesture(val label: String, val where: String) {
    BAR_SWIPE_LEFT   ("Swipe left on the bar",        "toolbar"),
    BAR_SWIPE_RIGHT  ("Swipe right on the bar",       "toolbar"),
    BAR_SWIPE_UP     ("Swipe up on the bar",          "toolbar"),
    BAR_SWIPE_DOWN   ("Swipe down on the bar",        "toolbar"),
    BAR_LONG_PRESS   ("Hold the bar",                 "toolbar"),
    BAR_DOUBLE_TAP   ("Double tap the bar",           "toolbar"),
    BAR_TWO_FINGER   ("Two fingers on the bar",       "toolbar"),

    EDGE_SWIPE_LEFT  ("Swipe in from the left edge",  "page"),
    EDGE_SWIPE_RIGHT ("Swipe in from the right edge", "page"),
    PAGE_TWO_UP      ("Two fingers up on the page",   "page"),
    PAGE_TWO_DOWN    ("Two fingers down on the page", "page"),
    PAGE_LONG_PRESS_EDGE("Hold the screen edge",      "page"),
}

enum class Action(val label: String) {
    NOTHING("Do nothing"),
    BACK("Go back"),
    FORWARD("Go forward"),
    RELOAD("Reload"),
    HOME("Go to Chalk"),
    NEW_TAB("New tab"),
    NEW_PRIVATE_TAB("New private tab"),
    CLOSE_TAB("Close tab"),
    REOPEN_TAB("Reopen closed tab"),
    NEXT_TAB("Next tab"),
    PREV_TAB("Previous tab"),
    SHOW_TABS("Show all tabs"),
    OPEN_TRAY("Open the Chalk Tray"),
    FIND("Find in page"),
    BOOKMARK("Bookmark this page"),
    TOP_OF_PAGE("Jump to the top"),
    BOTTOM_OF_PAGE("Jump to the bottom"),
    DESKTOP_SITE("Ask for the desktop site"),
    SHARE("Share this page"),
    READER("Reader view"),
    ZOOM_IN("Zoom in"),
    ZOOM_OUT("Zoom out"),
    FORGET("Clear browsing data"),
}

@Serializable
data class GestureMap(val map: Map<String, String> = DEFAULT) {

    operator fun get(g: Gesture): Action =
        runCatching { Action.valueOf(map[g.name] ?: "NOTHING") }.getOrElse { Action.NOTHING }

    fun with(g: Gesture, a: Action) = GestureMap(map + (g.name to a.name))

    companion object {
        const val FILE = "gestures.json"
        private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

        /** Sensible out of the box, all of it changeable. */
        val DEFAULT: Map<String, String> = mapOf(
            Gesture.BAR_SWIPE_LEFT.name    to Action.NEXT_TAB.name,
            Gesture.BAR_SWIPE_RIGHT.name   to Action.PREV_TAB.name,
            Gesture.BAR_SWIPE_UP.name      to Action.SHOW_TABS.name,
            Gesture.BAR_SWIPE_DOWN.name    to Action.RELOAD.name,
            Gesture.BAR_LONG_PRESS.name    to Action.OPEN_TRAY.name,
            Gesture.BAR_DOUBLE_TAP.name    to Action.TOP_OF_PAGE.name,
            Gesture.BAR_TWO_FINGER.name    to Action.CLOSE_TAB.name,
            Gesture.EDGE_SWIPE_LEFT.name   to Action.BACK.name,
            Gesture.EDGE_SWIPE_RIGHT.name  to Action.FORWARD.name,
            Gesture.PAGE_TWO_UP.name       to Action.NEW_TAB.name,
            Gesture.PAGE_TWO_DOWN.name     to Action.FIND.name,
            Gesture.PAGE_LONG_PRESS_EDGE.name to Action.NOTHING.name,
        )

        fun load(context: Context): GestureMap = runCatching {
            val f = java.io.File(context.filesDir, FILE)
            if (f.exists()) json.decodeFromString<GestureMap>(f.readText()) else GestureMap()
        }.getOrElse { GestureMap() }

        fun save(context: Context, gm: GestureMap) = runCatching {
            java.io.File(context.filesDir, FILE).writeText(json.encodeToString(gm))
        }
    }
}

/* ================================================================== *
 * the detector
 * ================================================================== */

/**
 * Swipes, with the number of fingers taken into account.
 *
 * [edgeMode] treats a drag that starts within [edgeWidth] of a side as an
 * edge swipe, which is how back and forward feel right on a phone.
 */
fun Modifier.swipes(
    enabled: Boolean = true,
    edgeMode: Boolean = false,
    onSwipe: (dir: Dir2, fingers: Int, fromEdge: Edge) -> Unit,
): Modifier = this.pointerInput(enabled, edgeMode) {
    if (!enabled) return@pointerInput

    val threshold = 56.dp.toPx()
    val edgeWidth = 28.dp.toPx()

    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val startX = down.position.x
        var dx = 0f
        var dy = 0f
        var fingers = 1
        var fired = false

        while (true) {
            val event = awaitPointerEvent()
            fingers = maxOf(fingers, event.changes.count { it.pressed })

            val change = event.changes.firstOrNull { it.id == down.id }
            if (change != null) {
                dx += change.positionChange().x
                dy += change.positionChange().y
            }

            if (!fired && (abs(dx) > threshold || abs(dy) > threshold)) {
                val dir = if (abs(dx) > abs(dy)) {
                    if (dx > 0) Dir2.RIGHT else Dir2.LEFT
                } else {
                    if (dy > 0) Dir2.DOWN else Dir2.UP
                }
                val edge = when {
                    !edgeMode -> Edge.NONE
                    startX < edgeWidth -> Edge.LEFT
                    startX > size.width - edgeWidth -> Edge.RIGHT
                    else -> Edge.NONE
                }
                onSwipe(dir, fingers, edge)
                fired = true
            }

            if (event.changes.none { it.pressed }) break
        }
    }
}

enum class Dir2 { LEFT, RIGHT, UP, DOWN }
enum class Edge { LEFT, RIGHT, NONE }

/** Long press and double tap, kept separate so they compose cleanly. */
fun Modifier.taps(
    enabled: Boolean = true,
    onLongPress: () -> Unit,
    onDoubleTap: () -> Unit,
): Modifier = this.pointerInput(enabled) {
    if (!enabled) return@pointerInput
    detectTapGestures(
        onLongPress = { onLongPress() },
        onDoubleTap = { onDoubleTap() },
    )
}

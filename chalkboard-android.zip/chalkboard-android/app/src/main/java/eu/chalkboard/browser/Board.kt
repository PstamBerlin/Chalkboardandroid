package eu.chalkboard.browser

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * A Board is the whole look of the browser as data.
 *
 * Nothing in the UI hard codes a colour or a size. Every widget reads from
 * here, which is why the tray can change anything without touching layout
 * code, and why a Board can be copied out as text and given to a friend.
 */
@Serializable
@Immutable
data class Board(
    // colours, stored as hex so they survive a round trip through text
    val stroke: String = "#FF7F5C",
    val bg: String = "#0A0A0B",
    val fill: String = "#1A1210",
    val page: String = "#111112",
    val ink: String = "#F2EFE9",
    val inkDim: String = "#8B8177",

    // outline
    val strokeWidth: Float = 2f,
    val glow: Float = 10f,

    // shape
    val radius: Float = 16f,
    val capsule: Float = 999f,
    val toolbarHeight: Float = 52f,
    val tabHeight: Float = 44f,
    val gap: Float = 6f,

    // type
    val fontSize: Float = 14f,
    val fontFamily: String = "system",

    // motion
    val speedMs: Int = 150,

    // your own picture, stored as a file name inside the app folder
    val wallpaper: String? = null,
    val wallpaperFade: Float = 1f,
    val wallpaperBlur: Float = 0f,
) {
    val cStroke get() = hex(stroke)
    val cBg     get() = hex(bg)
    val cFill   get() = hex(fill)
    val cPage   get() = hex(page)
    val cInk    get() = hex(ink)
    val cInkDim get() = hex(inkDim)

    val dStroke: Dp get() = strokeWidth.dp
    val dRadius: Dp get() = radius.dp
    val dCapsule: Dp get() = capsule.dp
    val dToolbar: Dp get() = toolbarHeight.dp
    val dTab: Dp get() = tabHeight.dp
    val dGap: Dp get() = gap.dp
    val tFont: TextUnit get() = fontSize.sp

    /** The outline colour at partial strength, for quieter borders. */
    fun faint(alpha: Float = 0.32f) = cStroke.copy(alpha = alpha)

    companion object {
        const val FILE = "board.json"
        private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

        fun hex(s: String): Color = runCatching {
            val h = s.removePrefix("#")
            val v = h.toLong(16)
            // Compose packs a Long as ARGB already, so an 8 digit value goes
            // straight in and a 6 digit one just needs full alpha added.
            if (h.length == 8) Color(v) else Color(0xFF000000L or v)
        }.getOrElse { Color.Magenta }

        fun toHex(c: Color): String {
            fun p(f: Float) = ((f * 255).toInt().coerceIn(0, 255)).toString(16).padStart(2, '0')
            return ("#" + p(c.red) + p(c.green) + p(c.blue)).uppercase()
        }

        val PRESETS: Map<String, Board> = linkedMapOf(
            "Ember" to Board(),
            "Ice" to Board(
                stroke = "#63D7E8", bg = "#070B0D", fill = "#0D1A1E",
                page = "#0B1214", ink = "#EAF6F8", inkDim = "#6E858B",
                glow = 16f, radius = 20f, gap = 7f
            ),
            "Chalk" to Board(
                stroke = "#F2EFE6", bg = "#12161A", fill = "#1A1F24",
                page = "#0E1113", ink = "#F2EFE6", inkDim = "#767C83",
                strokeWidth = 1f, glow = 0f, radius = 10f, capsule = 10f
            ),
            "Acid" to Board(
                stroke = "#00FF00", bg = "#000000", fill = "#001400",
                page = "#000000", ink = "#CFFFCF", inkDim = "#4E874E",
                glow = 22f, radius = 4f, capsule = 3f, speedMs = 60
            ),
            "Paper" to Board(
                stroke = "#2B2B2B", bg = "#F7F5F0", fill = "#FFFFFF",
                page = "#FFFFFF", ink = "#161616", inkDim = "#6B6B6B",
                strokeWidth = 1f, glow = 0f, radius = 8f, capsule = 8f
            ),
        )

        fun load(context: Context): Board = runCatching {
            val f = java.io.File(context.filesDir, FILE)
            if (f.exists()) json.decodeFromString<Board>(f.readText()) else Board()
        }.getOrElse { Board() }

        fun save(context: Context, board: Board) = runCatching {
            java.io.File(context.filesDir, FILE).writeText(json.encodeToString(board))
        }

        /** Turn a Board into a line of text you can send to someone. */
        fun export(board: Board): String = Json.encodeToString(board)

        fun import(text: String): Board? = runCatching {
            Json { ignoreUnknownKeys = true }.decodeFromString<Board>(text.trim())
        }.getOrNull()
    }
}

package eu.chalkboard.browser.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import eu.chalkboard.browser.*

/* ---------------------------------------------------------------- *
 * tab strip
 * ---------------------------------------------------------------- */

@Composable
fun TabStrip(browser: Browser) {
    val board = browser.board
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(board.dGap),
        contentPadding = PaddingValues(horizontal = 10.dp),
        modifier = Modifier.fillMaxWidth().height(board.dTab),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items(browser.tabs.size) { i ->
            val tab = browser.tabs[i]
            val on = i == browser.activeIndex
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                modifier = Modifier
                    .height(board.dTab - 12.dp)
                    .widthIn(max = 172.dp)
                    .clip(RoundedCornerShape(board.dCapsule))
                    .then(
                        if (on) Modifier
                            .background(board.cFill)
                            .border(board.dStroke, board.cStroke, RoundedCornerShape(board.dCapsule))
                        else Modifier
                    )
                    .clickable { browser.activeIndex = i }
                    .padding(horizontal = 10.dp),
            ) {
                if (browser.prefs.showFavicons) Favicon(tab.host, tab.private, board)
                Text(
                    tab.title,
                    color = if (on) board.cInk else board.cInkDim,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Text(
                    "\u00d7",
                    color = board.cInkDim,
                    fontSize = 15.sp,
                    modifier = Modifier.clickable { browser.closeTab(i) },
                )
            }
        }
        item {
            Text(
                "+",
                color = board.cStroke,
                fontSize = 19.sp,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable { browser.newTab() }
                    .padding(horizontal = 10.dp),
            )
        }
    }
}

@Composable
fun Favicon(host: String, private: Boolean, board: Board) {
    val seed = host.ifBlank { "chalk" }
    val hue = (seed.fold(0) { a, c -> (a * 31 + c.code) % 360 }).toFloat()
    Box(
        Modifier
            .size(17.dp)
            .clip(RoundedCornerShape(5.dp))
            .background(
                if (private) board.cInkDim
                else Color.hsl(hue, 0.6f, 0.62f)
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            (seed.firstOrNull() ?: 'C').uppercase(),
            color = Color(0xFF0A0A0B),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

/* ---------------------------------------------------------------- *
 * toolbar
 * ---------------------------------------------------------------- */

@Composable
fun Toolbar(browser: Browser) {
    val board = browser.board
    val tab = browser.active
    var editing by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(board.dGap),
        modifier = Modifier
            .fillMaxWidth()
            .height(board.dToolbar)
            .padding(horizontal = 10.dp),
    ) {
        RoundBtn(board, enabled = tab?.canBack == true, onClick = { browser.run(Action.BACK) }) {
            Text("\u2039", color = board.cStroke, fontSize = 19.sp)
        }

        // the address bar shows the site, not a wall of url
        Capsule(
            board,
            Modifier
                .weight(1f)
                .height(38.dp)
                .clickable {
                    editing = true
                    typed = if (tab?.url?.startsWith("chalk:") == true) "" else tab?.url.orEmpty()
                },
        ) {
            if (editing) {
                BasicTextField(
                    value = typed,
                    onValueChange = { typed = it },
                    singleLine = true,
                    textStyle = TextStyle(color = board.cInk, fontSize = 14.sp),
                    cursorBrush = SolidColor(board.cStroke),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        browser.go(typed)
                        editing = false
                    }),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                )
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                ) {
                    if (tab?.host?.isNotBlank() == true) {
                        Favicon(tab.host, tab.private, board)
                    }
                    Text(
                        tab?.host?.ifBlank { null } ?: "Search on Chalk, or type an address",
                        color = if (tab?.host.isNullOrBlank()) board.cInkDim else board.cInk,
                        fontSize = if (tab?.host.isNullOrBlank()) 13.sp else 15.sp,
                        fontWeight = if (tab?.host.isNullOrBlank()) FontWeight.Normal else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    if (tab?.secure == true) {
                        Text("\uD83D\uDD12", fontSize = 11.sp, color = board.cInkDim)
                    }
                }
            }
        }

        RoundBtn(board, active = browser.trayOpen, onClick = { browser.trayOpen = !browser.trayOpen }) {
            // the geometric C
            Text("C", color = board.cStroke, fontSize = 17.sp, fontWeight = FontWeight.Light)
        }
    }
}

/* ---------------------------------------------------------------- *
 * bars that appear when something happens
 * ---------------------------------------------------------------- */

@Composable
fun FindBar(browser: Browser) {
    val board = browser.board
    var text by remember { mutableStateOf("") }
    var found by remember { mutableStateOf(0 to 0) }

    AnimatedVisibility(browser.findOpen) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(board.dGap),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
        ) {
            Capsule(board, Modifier.weight(1f).height(36.dp)) {
                BasicTextField(
                    value = text,
                    onValueChange = { v ->
                        text = v
                        browser.active?.session?.finder?.find(v, 0)?.accept { r ->
                            if (r != null) found = r.current to r.total
                        }
                    },
                    singleLine = true,
                    textStyle = TextStyle(color = board.cInk, fontSize = 14.sp),
                    cursorBrush = SolidColor(board.cStroke),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                )
            }
            Text("${found.first} / ${found.second}", color = board.cInkDim, fontSize = 12.sp)
            RoundBtn(board, size = 32.dp, onClick = {
                browser.active?.session?.finder?.find(null, 0)
            }) { Text("\u2039", color = board.cStroke, fontSize = 16.sp) }
            RoundBtn(board, size = 32.dp, onClick = {
                browser.active?.session?.finder?.find(null, GeckoFindNext)
            }) { Text("\u203A", color = board.cStroke, fontSize = 16.sp) }
            RoundBtn(board, size = 32.dp, onClick = {
                browser.active?.session?.finder?.clear()
                browser.findOpen = false
            }) { Text("\u00d7", color = board.cStroke, fontSize = 16.sp) }
        }
    }
}

/** GeckoSession.Finder flag for "find the next one, do not start over". */
private const val GeckoFindNext = 1

@Composable
fun PopupBar(browser: Browser) {
    val board = browser.board
    val blocked = browser.blockedPopup
    AnimatedVisibility(blocked != null) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            Text(
                "Popup blocked",
                color = board.cInk, fontSize = 12.5.sp,
                modifier = Modifier.weight(1f),
            )
            Text(
                "Open it",
                color = board.cStroke, fontSize = 12.5.sp,
                modifier = Modifier.clickable {
                    blocked?.let { browser.newTab(it) }
                    browser.blockedPopup = null
                },
            )
            Text(
                "Dismiss",
                color = board.cInkDim, fontSize = 12.5.sp,
                modifier = Modifier.clickable { browser.blockedPopup = null },
            )
        }
    }
}

@Composable
fun PermissionBar(browser: Browser) {
    val board = browser.board
    val ask = browser.permissionAsk
    AnimatedVisibility(ask != null) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(
                "${ask?.origin} wants to ${ask?.what}.",
                color = board.cInk, fontSize = 12.5.sp,
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 8.dp),
            ) {
                Box(Modifier.weight(1f)) { PillButton("Block", board) { ask?.answer?.invoke(false) } }
                Box(Modifier.weight(1f)) { PillButton("Allow once", board, strong = true) { ask?.answer?.invoke(true) } }
            }
        }
    }
}
